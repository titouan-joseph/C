#ifndef C_TAB_ENTIER_H
#define C_TAB_ENTIER_H

int *creerTabEntier(int N);
void afficherTabEntier(int *tab,int N);
void remplirTabEntier(int *tab,int N);

#endif //C_TAB_ENTIER_H
