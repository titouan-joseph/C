
GRAPHE init_adj_mat(int nb_sommets);
GRAPHE read_adj_mat(char *nom_fich);
void affiche_adj_mat(FILE *fich,GRAPHE g);
void print_adj_dot(FILE *fich,GRAPHE g);
void affiche_adj_dot(char *nom_fich,GRAPHE g);
void dotty_adj_dot(GRAPHE g);


