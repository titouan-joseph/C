
GRAPHE liste_to_graphe(GRAPHE_LISTE g);
SOMMET *new_sommet(int num,ARC *arc);
GRAPHE_LISTE graphe_to_liste(GRAPHE g);
void affiche_graphe_liste(FILE *fich,GRAPHE_LISTE g);
