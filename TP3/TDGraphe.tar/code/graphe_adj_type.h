#ifndef GRAPHE_ADJ_TYPE_H
#define GRAPHE_ADJ_TYPE_H

struct graphe {
  int nb_sommets;
  int **adj;
};
typedef struct graphe GRAPHE;
 
#endif
