GRAPHE fermeture_transistive(GRAPHE g);
int *dijkstra(GRAPHE_POIDS g,int source);
