void  errorT(const char *mess);
void setVeryBigBigInt(bigInt bN);
int test_initBigInt();
int test_getNbChiffreInt();
int test_getNbChiffreBigInt();
int test_intToBigInt();
int test_stringToBigInt();
int test_sprintBigInt();




