#ifndef TYPE_BIGINT_H
#define TYPE_BIGINT_H

#define TAILLEMAX 1000

typedef int *bigInt;

#endif
