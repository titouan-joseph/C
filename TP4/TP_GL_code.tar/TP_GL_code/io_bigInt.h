#ifndef IO_BIGINT_H
#define IO_BIGINT_H

int readBigInt(FILE *fich,bigInt res);
int writeBigInt(FILE *fich, bigInt bN);

#endif
