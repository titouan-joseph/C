void testBinopFile(char *file,int (*func)(bigInt,bigInt,bigInt));
void  errorT(const char *mess);
