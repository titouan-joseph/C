#ifndef list_h_
#define list_h_


void afficherListe(LISTE);	
LISTE AjouterListeTrie (LISTE, int);
void AjouterListeTrie2 (LISTE*, int);
void fusion (LISTE *pliste1, LISTE *pliste2);

#endif
